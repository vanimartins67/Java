package Lista2;

public class Lista2Exercicio1 {
    public static void main(String[] args) {
        int i = 10;
        while (i >= 0) {
            System.out.println(i);
            i--;
        }
        System.out.println("FIM!");
    }
}