package Lista2;
public class Lista2Exercicio5 {
    public static void main(String[] args) {
        int numero = 0;
        while (numero <= 100000) {
            System.out.println(numero);
            numero += 1000;
        }
    }
}